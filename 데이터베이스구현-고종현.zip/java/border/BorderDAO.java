package border;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class BorderDAO {

	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
		
	//		---------- DB���� ----------  //
	public BorderDAO() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/BBS_db";//mysql ��ġ
			String dbID = "root";//mysql ID
			String dbPassword = "root";//mysql PASSWORD
			Class.forName("com.mysql.cj.jdbc.Driver");//���� ����̹�
			conn=DriverManager.getConnection(dbURL, dbID, dbPassword);//DB�������� �� ����
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//�ڵ����� ��ȣ
	public int getNext() {
		String SQL = "SELECT ȸ����ȣ FROM Border ORDER BY ȸ����ȣ DESC";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1) + 1;
			}else {
				return 1;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;//����
	}
		
	//������
	public int write(Integer Number, String Title, String Content) {
		String SQL = "INSERT INTO Border VALUES(?,?,?)";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());
			pstmt.setString(2, Title);
			pstmt.setString(3, Content);
			return pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;//�����ͺ��̽� ����
	}


		
	//���
	public ArrayList<Border> getList(){
		String SQL = "SELECT * FROM Border ORDER BY ȸ����ȣ DESC";                        
		ArrayList<Border> list = new ArrayList<Border>();
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				Border border = new Border();
				border.setNumber(rs.getInt(1));
				border.setTitle(rs.getString(2));
				border.setContent(rs.getString(3));
				list.add(border);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	//�����б�
	 public Border getBorder(int Number) {
		 String SQL = "SELECT * FROM Border WHERE ȸ����ȣ = ?";
		 try {
				PreparedStatement pstmt=conn.prepareStatement(SQL);
				pstmt.setInt(1, Number);
				rs=pstmt.executeQuery();
				if(rs.next()) {
					Border border = new Border();
					border.setNumber(rs.getInt(1));
					border.setTitle(rs.getString(2));
					border.setContent(rs.getString(3));
					return border;
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		 return null;
	 }

	

	
	
	
}